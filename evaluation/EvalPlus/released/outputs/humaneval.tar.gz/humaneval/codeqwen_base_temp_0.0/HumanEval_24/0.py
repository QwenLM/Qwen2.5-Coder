

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """

    if n == 0:
        return 0
    if n == 1:
        return 1
    if n == 2:
        return 2
    if n == 3:
        return 3
    if n == 4:
        return 4
    if n == 5:
        return 5
    if n == 6:
        return 6
    if n == 7:
        return 7
    if n == 8:
        return 8
    if n == 9:
        return 9
    if n == 10:
        return 10
    if n == 11:
        return 11
    if n == 12:
        return 12
    if n == 13:
        return 13
    if n == 14:
        return 14
    if n == 15:
        return 15
    if n == 16:
        return 16
    if n == 17:
        return 17
    if n == 18:
        return 18
    if n == 19:
        return 19
    if n == 20:
        return 20
    if n == 21:
        return 21
    if n == 22:
        return 22
    if n == 23:
        return 23
    if n == 24:
        return 24
    if n == 25:
        return 25
    if n == 26:
        return 26
    if n == 27:
        return 27
    if n == 28:
        return 28
    if n == 29:
        return 29
    if n == 30:
        return 30
    if n == 31:
        return 31
    if n == 32:
        return 32
    if n == 33:
        return 33
    if n == 34:
        return 34
    if n == 35:
        return 35
    if n == 36:
        return 36
    if n == 37:
        return 37
    if n == 38:
        return 38
    if n ==