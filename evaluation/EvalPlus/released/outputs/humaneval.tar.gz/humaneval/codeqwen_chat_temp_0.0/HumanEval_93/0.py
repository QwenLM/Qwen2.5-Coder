def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    vowels = 'aeiou'
    encoded_message = ''
    for char in message:
        if char.isalpha():
            if char.lower() in vowels:
                # Find the next vowel in the alphabet
                next_vowel = chr((ord(char.lower()) - 97 + 2) % 26 + 97)
                # Swap case and replace vowel
                encoded_message += next_vowel.swapcase()
            else:
                # Swap case for consonants
                encoded_message += char.swapcase()
        else:
            # Keep non-alphabetic characters as is
            encoded_message += char
    return encoded_message