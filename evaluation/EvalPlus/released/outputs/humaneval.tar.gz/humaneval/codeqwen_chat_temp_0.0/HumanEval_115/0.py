import math

def max_fill(grid, capacity):
    total_drops = 0
    for row in grid:
        total_drops += math.ceil(sum(row) / capacity)
    return total_drops