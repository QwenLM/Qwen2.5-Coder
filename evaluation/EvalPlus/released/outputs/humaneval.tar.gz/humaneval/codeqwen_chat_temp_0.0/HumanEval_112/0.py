def reverse_delete(s,c):
    s = s.replace(''.join(c), '')
    return (s, s == s[::-1])