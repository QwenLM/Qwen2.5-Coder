from collections import deque

def minPath(grid, k):
    N = len(grid)
    visited = set()
    queue = deque([(i, j, [grid[i][j]]) for i in range(N) for j in range(N)])
    
    while queue:
        x, y, path = queue.popleft()
        if len(path) == k:
            return path
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx, ny = x + dx, y + dy
            if 0 <= nx < N and 0 <= ny < N and (nx, ny) not in visited:
                visited.add((nx, ny))
                queue.append((nx, ny, path + [grid[nx][ny]]))