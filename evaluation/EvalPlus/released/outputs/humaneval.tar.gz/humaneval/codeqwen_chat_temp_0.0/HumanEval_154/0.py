def cycpattern_check(a , b):
    # Concatenate the first string with itself
    concat_a = a + a
    
    # Check if the second string is a substring of the concatenated string
    return b in concat_a