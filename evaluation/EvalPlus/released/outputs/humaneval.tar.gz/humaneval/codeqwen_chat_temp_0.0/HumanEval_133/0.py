import math

def sum_squares(lst):
    return sum(math.ceil(num)**2 for num in lst)