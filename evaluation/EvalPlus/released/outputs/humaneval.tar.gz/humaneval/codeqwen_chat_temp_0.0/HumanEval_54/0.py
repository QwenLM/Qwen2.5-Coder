def same_chars(s0: str, s1: str) -> bool:
    return set(s0) == set(s1)