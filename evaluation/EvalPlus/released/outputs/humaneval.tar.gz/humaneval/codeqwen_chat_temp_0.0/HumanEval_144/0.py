def simplify(x, n):
    # Split the fractions into numerator and denominator
    x_numerator, x_denominator = map(int, x.split('/'))
    n_numerator, n_denominator = map(int, n.split('/'))

    # Calculate the product of the numerators and denominators
    product_numerator = x_numerator * n_numerator
    product_denominator = x_denominator * n_denominator

    # Check if the product is a whole number
    return product_numerator % product_denominator == 0