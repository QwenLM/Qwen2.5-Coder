def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    # Check if n is even and greater than or equal to 8
    if n % 2 == 0 and n >= 8:
        # Subtract the smallest possible sum of 4 even numbers (2+2+2+2=8) from n
        n -= 8
        # Check if the result is even and greater than or equal to 0
        if n % 2 == 0 and n >= 0:
            return True
    return False