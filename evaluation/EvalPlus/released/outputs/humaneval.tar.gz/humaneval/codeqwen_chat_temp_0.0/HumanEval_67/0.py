def fruit_distribution(s,n):
    # Split the string into two parts: the number of apples and oranges
    parts = s.split()
    apples = int(parts[0])
    oranges = int(parts[3])
    
    # Calculate the number of mangoes
    mangoes = n - apples - oranges
    
    return mangoes