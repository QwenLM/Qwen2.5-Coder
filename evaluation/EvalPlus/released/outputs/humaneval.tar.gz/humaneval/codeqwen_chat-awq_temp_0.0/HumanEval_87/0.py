def get_row(lst, x):
    coordinates = []
    for i, row in enumerate(lst):
        for j, num in enumerate(row[::-1]):
            if num == x:
                coordinates.append((i, len(row) - 1 - j))
    coordinates.sort(key=lambda x: (x[0], -x[1]))
    return coordinates