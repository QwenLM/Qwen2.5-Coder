def sorted_list_sum(lst):
    # Remove strings with odd lengths
    even_length_lst = [s for s in lst if len(s) % 2 == 0]
    
    # Sort the list by length, then alphabetically
    even_length_lst.sort(key=lambda x: (len(x), x))
    
    return even_length_lst