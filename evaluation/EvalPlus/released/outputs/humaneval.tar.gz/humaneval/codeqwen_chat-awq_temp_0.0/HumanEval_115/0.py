def max_fill(grid, capacity):
    total_drops = 0
    for row in grid:
        total_drops += math.ceil(row.count(1) / capacity)
    return total_drops