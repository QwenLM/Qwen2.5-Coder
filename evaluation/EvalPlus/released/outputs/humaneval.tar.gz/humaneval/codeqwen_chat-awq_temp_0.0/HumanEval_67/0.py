def fruit_distribution(s,n):
    numbers = [int(num) for num in s.split() if num.isdigit()]
    return n - sum(numbers)