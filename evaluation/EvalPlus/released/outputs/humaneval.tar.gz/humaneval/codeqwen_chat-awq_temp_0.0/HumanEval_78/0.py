def hex_key(num):
    # Define the prime hexadecimal digits
    prime_hex_digits = {'2', '3', '5', '7', 'B', 'D'}
    
    # Count the number of prime hexadecimal digits in the input string
    prime_count = sum(1 for digit in num if digit in prime_hex_digits)
    
    # Return the count
    return prime_count