def simplify(x, n):
    # Split the numerator and denominator of x
    x_numerator, x_denominator = map(int, x.split('/'))
    # Split the numerator and denominator of n
    n_numerator, n_denominator = map(int, n.split('/'))
    # Multiply the numerators and denominators
    result_numerator = x_numerator * n_numerator
    result_denominator = x_denominator * n_denominator
    # Check if the result is a whole number
    return result_numerator % result_denominator == 0