def move_zero(lst):
    non_zero = [i for i in lst if i != 0]
    zero = [i for i in lst if i == 0]
    return non_zero + zero