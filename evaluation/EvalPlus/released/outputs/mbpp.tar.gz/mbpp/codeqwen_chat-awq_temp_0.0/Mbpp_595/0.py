def min_Swaps(str1, str2):
    # Initialize variables
    n = len(str1)
    count = 0
    i = 0
    j = n - 1
    
    # Loop through the string from both ends
    while i < j:
        # If characters at current positions are not equal, increment count
        if str1[i] != str2[j]:
            count += 1
        # Move pointers towards each other
        i += 1
        j -= 1
    
    # Return the count of swaps
    return count