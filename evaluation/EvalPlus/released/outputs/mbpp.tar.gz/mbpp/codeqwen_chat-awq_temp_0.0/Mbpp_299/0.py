def max_aggregate(tuples):
    # Create a dictionary to store the sum of each name
    name_sum = {}
    for name, score in tuples:
        if name in name_sum:
            name_sum[name] += score
        else:
            name_sum[name] = score
    # Find the name with the maximum sum
    max_name = max(name_sum, key=name_sum.get)
    return (max_name, name_sum[max_name])