def diff_even_odd(lst):
    first_even = next((num for num in lst if num % 2 == 0), None)
    first_odd = next((num for num in lst if num % 2 != 0), None)
    return first_even - first_odd if first_even is not None and first_odd is not None else None