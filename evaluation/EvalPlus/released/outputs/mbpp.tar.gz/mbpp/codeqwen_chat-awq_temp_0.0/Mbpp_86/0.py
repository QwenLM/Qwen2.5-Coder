def centered_hexagonal_number(n):
    return 3*n*(n-1) + 1