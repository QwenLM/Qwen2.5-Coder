def count_bidirectional(pairs):
    count = 0
    for pair in pairs:
        if (pair[1], pair[0]) in pairs:
            count += 1
    return count