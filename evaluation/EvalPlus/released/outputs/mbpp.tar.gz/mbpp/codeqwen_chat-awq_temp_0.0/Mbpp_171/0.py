def perimeter_pentagon(side_length):
    return 5 * side_length