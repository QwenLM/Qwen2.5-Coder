def magic_square_test(matrix):
    n = len(matrix)
    if n == 0:
        return False
    
    # Check if all rows and columns sum up to the same value
    for i in range(n):
        if sum(matrix[i]) != sum(matrix[0]):
            return False
        if sum(matrix[j][i] for j in range(n)) != sum(matrix[0]):
            return False
    
    # Check if the diagonals sum up to the same value
    if sum(matrix[i][i] for i in range(n)) != sum(matrix[0]):
        return False
    if sum(matrix[i][n-1-i] for i in range(n)) != sum(matrix[0]):
        return False
    
    return True