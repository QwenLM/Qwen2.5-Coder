from math import factorial

def sum_Of_product(n):
    sum = 0
    for i in range(n):
        sum += factorial(n) // (factorial(i) * factorial(n - i - 1))
    return sum