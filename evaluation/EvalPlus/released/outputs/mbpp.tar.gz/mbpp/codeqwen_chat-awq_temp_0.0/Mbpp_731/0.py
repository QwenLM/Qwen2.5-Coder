import math

def lateralsurface_cone(r, h):
    l = math.sqrt(h**2 + r**2)
    lsa = math.pi * r * l
    return lsa