def return_sum(d):
    return sum(d.values())