def smallest_num(numbers):
    return min(numbers)