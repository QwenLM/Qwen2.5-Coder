import math

def area_tetrahedron(side_length):
    """
    Calculate the area of a tetrahedron given the length of its side.
    
    Args:
    side_length (float): The length of the side of the tetrahedron.
    
    Returns:
    float: The area of the tetrahedron.
    """
    return math.sqrt(3) * (side_length ** 2)