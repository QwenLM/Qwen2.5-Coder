def frequency(lst, num):
    return lst.count(num)