def _sum(arr):
    sum = 0
    for i in arr:
        sum += i
    return sum