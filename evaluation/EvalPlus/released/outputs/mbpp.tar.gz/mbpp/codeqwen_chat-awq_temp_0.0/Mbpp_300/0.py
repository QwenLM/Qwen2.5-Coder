import math

def count_binary_seq(n):
    # Initialize the result
    result = 0
    # Loop over all possible sums of the first n bits
    for i in range(n+1):
        # Calculate the number of sequences with the given sum of the first n bits
        # and the same sum of the last n bits
        result += math.comb(n, i) ** 2
    # Return the result
    return result