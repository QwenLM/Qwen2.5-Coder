def find(num1, num2):
    quotient = num1 // num2
    return quotient