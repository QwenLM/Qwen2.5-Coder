def is_samepatterns(colors, patterns):
    if len(colors) != len(patterns):
        return False
    pattern_to_color = {}
    for i in range(len(patterns)):
        if patterns[i] not in pattern_to_color:
            pattern_to_color[patterns[i]] = colors[i]
        elif pattern_to_color[patterns[i]] != colors[i]:
            return False
    return True