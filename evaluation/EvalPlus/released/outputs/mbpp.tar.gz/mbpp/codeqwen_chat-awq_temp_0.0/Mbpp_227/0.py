def min_of_three(a, b, c):
    return min(a, b, c)