def shell_sort(arr):
    n = len(arr)
    interval = n // 2
    while interval > 0:
        for index in range(interval, n):
            temp = arr[index]
            position = index
            while position >= interval and arr[position - interval] > temp:
                arr[position] = arr[position - interval]
                position -= interval
            arr[position] = temp
        interval //= 2
    return arr