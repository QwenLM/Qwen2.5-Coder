def sort_matrix(matrix):
    return sorted(matrix, key=sum)