def pos_count(lst):
    count = 0
    for num in lst:
        if num > 0:
            count += 1
    return count