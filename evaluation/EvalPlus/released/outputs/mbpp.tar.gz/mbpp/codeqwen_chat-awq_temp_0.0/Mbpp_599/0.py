def sum_average(n):
    sum_n = sum(range(1, n+1))
    avg_n = sum_n / n
    return sum_n, avg_n