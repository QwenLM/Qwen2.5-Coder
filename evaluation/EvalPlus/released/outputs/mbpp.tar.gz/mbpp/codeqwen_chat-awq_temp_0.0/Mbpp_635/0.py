def heap_sort(nums):
    # Convert nums into a heap
    for i in range(len(nums) // 2 - 1, -1, -1):
        heapify(nums, len(nums), i)

    # Pop elements from the heap
    for i in range(len(nums) - 1, 0, -1):
        nums[i], nums[0] = nums[0], nums[i]  # Swap
        heapify(nums, i, 0)

    return nums

def heapify(nums, n, i):
    largest = i  # Initialize largest as root
    left = 2 * i + 1  # left = 2*i + 1
    right = 2 * i + 2  # right = 2*i + 2

    # If left child is larger than root
    if left < n and nums[i] < nums[left]:
        largest = left

    # If right child is larger than largest so far
    if right < n and nums[largest] < nums[right]:
        largest = right

    # If largest is not root
    if largest != i:
        nums[i], nums[largest] = nums[largest], nums[i]  # Swap
        # Recursively heapify the affected sub-tree
        heapify(nums, n, largest)