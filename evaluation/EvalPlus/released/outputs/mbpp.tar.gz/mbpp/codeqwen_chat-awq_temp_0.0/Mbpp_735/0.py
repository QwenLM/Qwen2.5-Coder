def toggle_middle_bits(n):
    # Initialize result and count
    result = 0
    count = 0
    
    # Copy of the number
    temp = n
    
    # Loop until all bits are processed
    while temp > 0:
        # Increment count
        count += 1
        
        # If count is not first or last bit, toggle the bit
        if count != 1 and count != count:
            result |= (1 << count)
        
        # Right shift temp by 1
        temp >>= 1
    
    # XOR the original number with the result to toggle the middle bits
    return n ^ result