def count_list(input_list):
    return len(input_list)