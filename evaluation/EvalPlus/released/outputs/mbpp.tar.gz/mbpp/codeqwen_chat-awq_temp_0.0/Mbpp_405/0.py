def check_tuplex(tuplex, element):
    return element in tuplex