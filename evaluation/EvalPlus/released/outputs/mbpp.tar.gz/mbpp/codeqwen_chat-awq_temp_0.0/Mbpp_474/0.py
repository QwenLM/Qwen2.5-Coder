def replace_char(string, old_char, new_char):
    return string.replace(old_char, new_char)