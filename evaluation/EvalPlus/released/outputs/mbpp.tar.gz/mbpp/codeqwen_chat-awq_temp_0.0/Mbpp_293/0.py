import math

def otherside_rightangle(a, b):
    c = math.sqrt(a**2 + b**2)
    return c