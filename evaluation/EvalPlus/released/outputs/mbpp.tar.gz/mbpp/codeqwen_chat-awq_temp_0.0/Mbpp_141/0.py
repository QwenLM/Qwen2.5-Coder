def pancake_sort(arr):
    n = len(arr)
    for i in range(n, 1, -1):
        # Find the index of the maximum element in arr[0..i-1]
        max_idx = arr.index(max(arr[:i]))
        
        # Move the maximum element to the beginning if it's not already there
        if max_idx != i-1:
            # Flip the array from 0 to max_idx
            arr[:max_idx+1] = arr[:max_idx+1][::-1]
            # Flip the array from 0 to i-1
            arr[:i] = arr[:i][::-1]
    return arr