def multiple_to_single(lst):
    return int(''.join(str(i) for i in lst))