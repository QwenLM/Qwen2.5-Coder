import math

def circle_circumference(radius):
    return 2 * math.pi * radius