def set_left_most_unset_bit(n):
    # If n is 0, return 1
    if n == 0:
        return 1
    # If n is already a power of 2, return n
    if n & (n - 1) == 0:
        return n
    # Find the leftmost unset bit
    leftmost_unset_bit = 1
    while n & leftmost_unset_bit:
        leftmost_unset_bit <<= 1
    # Set the leftmost unset bit
    return n | leftmost_unset_bit