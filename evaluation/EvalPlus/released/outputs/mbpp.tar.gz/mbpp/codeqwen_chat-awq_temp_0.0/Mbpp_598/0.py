def armstrong_number(n):
    # Convert the number to a string to easily iterate over each digit
    str_n = str(n)
    # Calculate the number of digits in the number
    num_digits = len(str_n)
    # Initialize the sum to 0
    sum = 0
    # Iterate over each digit in the number
    for digit in str_n:
        # Add the digit raised to the power of the number of digits to the sum
        sum += int(digit) ** num_digits
    # Return True if the sum is equal to the original number, False otherwise
    return sum == n