def cal_sum(n):
    # Initialize the first three Perrin numbers
    p0, p1, p2 = 3, 0, 2

    # If n is less than 3, return the sum of the first n Perrin numbers
    if n < 3:
        return sum(range(n+1))

    # Initialize the sum of the first three Perrin numbers
    sum_perrin = p0 + p1 + p2

    # Calculate the next Perrin numbers and update the sum
    while n > 2:
        p3 = p0 + p1
        sum_perrin += p3
        p0, p1, p2 = p1, p2, p3
        n -= 1

    return sum_perrin