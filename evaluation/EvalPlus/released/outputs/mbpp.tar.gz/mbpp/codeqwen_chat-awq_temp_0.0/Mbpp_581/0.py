def surface_Area(base_edge, height):
    return (base_edge * base_edge * height) + (2 * base_edge * base_edge)