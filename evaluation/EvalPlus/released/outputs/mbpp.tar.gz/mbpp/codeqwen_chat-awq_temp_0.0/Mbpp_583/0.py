def catalan_number(n):
    if n <= 1:
        return 1
    catalan = 0
    for i in range(n):
        catalan += catalan_number(i) * catalan_number(n-i-1)
    return catalan