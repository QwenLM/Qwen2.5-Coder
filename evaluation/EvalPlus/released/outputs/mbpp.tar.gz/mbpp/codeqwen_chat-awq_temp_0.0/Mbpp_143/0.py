def find_lists(tup):
    return sum(isinstance(i, list) for i in tup)