def rotate_right(lst, n):
    n = n % len(lst)  # To handle cases where n is greater than the length of the list
    return lst[-n:] + lst[:-n]