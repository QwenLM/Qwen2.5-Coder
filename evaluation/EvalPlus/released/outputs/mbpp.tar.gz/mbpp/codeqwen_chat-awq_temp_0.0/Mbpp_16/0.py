import re

def text_lowercase_underscore(text):
    pattern = '^[a-z]+_[a-z]+$'
    return bool(re.match(pattern, text))