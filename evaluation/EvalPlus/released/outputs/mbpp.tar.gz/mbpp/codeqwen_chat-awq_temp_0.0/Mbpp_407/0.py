def rearrange_bigger(n):
    # Convert the number to a list of its digits
    digits = list(str(n))
    
    # Traverse the list from the second last digit to the beginning
    for i in range(len(digits)-2, -1, -1):
        # If the current digit is less than the digit after it
        if digits[i] < digits[i+1]:
            # Extract the part of the list from the current digit to the end
            tail = digits[i:]
            # Find the smallest digit in the tail that is bigger than the current digit
            min_bigger = min(filter(lambda x: x > tail[0], tail))
            # Remove this digit from the tail
            tail.remove(min_bigger)
            # Sort the remaining tail digits
            tail.sort()
            # Combine the parts together to form the new number
            digits[i:] = [min_bigger] + tail
            # Return the new number as an integer
            return int("".join(digits))
    # If no bigger number can be formed, return -1
    return -1