def ascii_value(char):
    return ord(char)