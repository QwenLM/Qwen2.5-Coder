def intersection_array(arr1, arr2):
    # Use set to find common elements
    common_elements = set(arr1) & set(arr2)
    # Convert set back to list and return
    return list(common_elements)