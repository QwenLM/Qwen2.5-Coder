def is_majority(arr, n, x):
    # Find the first occurrence of x in arr[]
    i = arr.index(x) if x in arr else -1
    
    # If x is not present in arr[] or the first occurrence of x is at an index
    # greater than n/2, then x cannot be the majority element
    if i == -1 or i > n // 2:
        return False
    
    # Check if the element at index i + n/2 is x
    return arr[i + n // 2] == x