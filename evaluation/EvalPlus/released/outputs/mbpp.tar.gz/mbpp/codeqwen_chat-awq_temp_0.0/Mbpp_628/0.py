def replace_spaces(input_string):
    return input_string.replace(' ', '%20')