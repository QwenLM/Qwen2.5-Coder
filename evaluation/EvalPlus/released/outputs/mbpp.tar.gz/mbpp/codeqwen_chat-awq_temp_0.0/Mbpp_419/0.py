def round_and_sum(numbers):
    total = sum(map(round, numbers))
    return total * len(numbers)