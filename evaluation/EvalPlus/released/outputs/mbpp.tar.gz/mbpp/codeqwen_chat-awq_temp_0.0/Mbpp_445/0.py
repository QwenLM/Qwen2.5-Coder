def index_multiplication(tup1, tup2):
    result = tuple(tuple(a * b for a, b in zip(sub_tup1, sub_tup2)) for sub_tup1, sub_tup2 in zip(tup1, tup2))
    return result