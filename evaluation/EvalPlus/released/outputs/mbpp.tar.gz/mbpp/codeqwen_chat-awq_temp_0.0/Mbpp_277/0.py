def dict_filter(dictionary, n):
    return {k: v for k, v in dictionary.items() if v >= n}