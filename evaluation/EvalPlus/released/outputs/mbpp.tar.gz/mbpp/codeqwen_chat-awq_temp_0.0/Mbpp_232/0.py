def larg_nnum(lst, n):
    return sorted(lst, reverse=True)[:n]