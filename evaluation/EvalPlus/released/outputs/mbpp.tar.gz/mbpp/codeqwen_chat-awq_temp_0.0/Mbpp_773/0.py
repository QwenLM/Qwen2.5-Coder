def occurance_substring(string, substring):
    try:
        return (substring, string.index(substring), string.index(substring) + len(substring))
    except ValueError:
        return None