def odd_Equivalent(binary, rotations):
    # Initialize the count of odd equivalent numbers
    count = 0
    
    # Iterate over all possible rotations
    for i in range(rotations):
        # Rotate the binary string
        binary = binary[-1] + binary[:-1]
        
        # Check if the binary string is odd equivalent
        if int(binary, 2) % 2 != 0:
            count += 1
            
    return count