def square_Sum(n):
    return (n * (n + 1) * (2 * n + 1)) // 3