def tuple_intersection(tup1, tup2):
    # Convert tuples to sets
    set1 = set(tup1)
    set2 = set(tup2)
    
    # Find intersection of sets
    intersection = set1 & set2
    
    # Convert intersection back to tuple
    result = tuple(intersection)
    
    return result