def remove_all_spaces(string):
    return string.replace(" ", "")