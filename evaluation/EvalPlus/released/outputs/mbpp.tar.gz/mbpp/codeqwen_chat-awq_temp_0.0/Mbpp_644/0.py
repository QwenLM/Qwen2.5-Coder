def reverse_Array_Upto_K(arr, k):
    # Reverse the first k elements
    arr[:k] = arr[:k][::-1]
    # Reverse the remaining elements
    arr[k:] = arr[k:][::-1]
    # Return the modified array
    return arr