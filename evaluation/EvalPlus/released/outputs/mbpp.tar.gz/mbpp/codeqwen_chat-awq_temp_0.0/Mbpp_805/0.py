def max_sum_list(list_of_lists):
    max_sum = float('-inf')
    max_list = []
    for lst in list_of_lists:
        current_sum = sum(lst)
        if current_sum > max_sum:
            max_sum = current_sum
            max_list = lst
    return max_list