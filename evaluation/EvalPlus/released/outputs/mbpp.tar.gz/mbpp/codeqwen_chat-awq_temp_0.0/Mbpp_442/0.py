def positive_count(arr):
    total_numbers = len(arr)
    positive_numbers = sum(1 for num in arr if num > 0)
    return positive_numbers / total_numbers