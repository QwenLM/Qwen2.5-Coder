def big_sum(arr):
    return max(arr) + min(arr)