def hexagonal_num(n):
    return n * (2 * n - 1)