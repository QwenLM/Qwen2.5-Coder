def digit_distance_nums(num1, num2):
    # Convert the numbers to strings
    str_num1 = str(num1)
    str_num2 = str(num2)

    # Initialize the sum of the per-digit differences
    sum_diff = 0

    # Iterate over the digits of the two numbers
    for i in range(max(len(str_num1), len(str_num2))):
        # Get the digit from each number at the current position
        digit1 = int(str_num1[i]) if i < len(str_num1) else 0
        digit2 = int(str_num2[i]) if i < len(str_num2) else 0

        # Add the absolute difference between the digits to the sum
        sum_diff += abs(digit1 - digit2)

    # Return the sum of the per-digit differences
    return sum_diff