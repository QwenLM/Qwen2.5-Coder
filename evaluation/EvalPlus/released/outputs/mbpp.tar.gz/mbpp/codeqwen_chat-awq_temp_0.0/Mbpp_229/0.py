def re_arrange_array(arr, n):
    neg = [i for i in arr[:n] if i < 0]
    pos = [i for i in arr[:n] if i >= 0]
    return neg + pos