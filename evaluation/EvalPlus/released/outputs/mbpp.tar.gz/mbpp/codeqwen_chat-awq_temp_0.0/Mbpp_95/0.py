def Find_Min_Length(list_of_lists):
    # Find the length of the smallest list
    min_length = min(len(lst) for lst in list_of_lists)
    return min_length