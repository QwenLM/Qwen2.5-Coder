def is_octagonal(n):
    return 3 * n * n - 2 * n