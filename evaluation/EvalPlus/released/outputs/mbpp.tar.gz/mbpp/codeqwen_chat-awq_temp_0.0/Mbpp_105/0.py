def count_true_booleans(lst):
    return lst.count(True)