def find_star_num(n):
    if n < 1:
        return "Input should be a positive integer"
    else:
        return (6 * n * (n - 1) + 1)