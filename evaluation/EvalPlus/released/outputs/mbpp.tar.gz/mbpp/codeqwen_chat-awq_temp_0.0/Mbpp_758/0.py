def unique_sublists(lst):
    # Convert each sublist to a tuple
    tuples = [tuple(sublist) for sublist in lst]
    # Use a dictionary comprehension to count occurrences of each tuple
    counts = {t: tuples.count(t) for t in tuples}
    return counts