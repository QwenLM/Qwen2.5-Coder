def move_num(s):
    numbers = ''.join(filter(str.isdigit, s))
    letters = ''.join(filter(str.isalpha, s))
    return letters + numbers