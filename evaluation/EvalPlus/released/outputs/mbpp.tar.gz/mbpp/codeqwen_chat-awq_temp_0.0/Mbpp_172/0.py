def count_occurrence(s):
    return s.count('std')