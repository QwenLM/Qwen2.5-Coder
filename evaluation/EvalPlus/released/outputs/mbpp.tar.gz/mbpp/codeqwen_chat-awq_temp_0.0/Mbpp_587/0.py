def list_tuple(lst):
    return tuple(lst)