def median_trapezium(a, b, c):
    return (a + b) / 2