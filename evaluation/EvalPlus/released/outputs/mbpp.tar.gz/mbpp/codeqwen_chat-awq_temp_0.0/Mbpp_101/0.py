def kth_element(arr, k):
    # Sort the array
    arr.sort()
    # Return the kth element
    return arr[k-1]