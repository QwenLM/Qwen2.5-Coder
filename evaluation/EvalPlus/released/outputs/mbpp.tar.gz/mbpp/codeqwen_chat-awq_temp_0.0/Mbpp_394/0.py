def check_distinct(tup):
    return len(tup) == len(set(tup))