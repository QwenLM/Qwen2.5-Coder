def sort_counter(d):
    return sorted(d.items(), key=lambda x: x[1], reverse=True)