def find_substring(lst, substring):
    return any(substring in item for item in lst)