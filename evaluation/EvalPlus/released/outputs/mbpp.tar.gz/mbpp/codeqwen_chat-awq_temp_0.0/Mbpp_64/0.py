def subject_marks(lst):
    return sorted(lst, key=lambda x: x[1])