def find_min_diff(arr, n):
    # Sort the array
    arr.sort()
    
    # Initialize the minimum difference to be the maximum possible integer
    min_diff = float('inf')
    
    # Iterate through the array, comparing each element with the next one
    for i in range(n-1):
        # If the difference between the two elements is smaller than the current minimum difference,
        # update the minimum difference
        if arr[i+1] - arr[i] < min_diff:
            min_diff = arr[i+1] - arr[i]
    
    # Return the minimum difference
    return min_diff