def all_unique(lst):
    return len(lst) == len(set(lst))