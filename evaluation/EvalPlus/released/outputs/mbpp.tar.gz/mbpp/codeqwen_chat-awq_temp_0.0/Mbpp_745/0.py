def divisible_by_digits(startnum, endnum):
    result = []
    for num in range(startnum, endnum + 1):
        digits = set(str(num))
        if all(int(digit) != 0 and num % int(digit) == 0 for digit in digits):
            result.append(num)
    return result