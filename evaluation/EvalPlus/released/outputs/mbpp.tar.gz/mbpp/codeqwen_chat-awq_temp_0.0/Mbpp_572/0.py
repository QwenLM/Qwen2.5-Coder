def two_unique_nums(nums):
    return list(set(nums))