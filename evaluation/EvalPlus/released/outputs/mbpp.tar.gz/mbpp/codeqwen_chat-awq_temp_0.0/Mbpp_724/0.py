def power_base_sum(base, power):
    # Calculate the base to the power
    result = base ** power
    
    # Convert the result to a string to iterate over each digit
    result_str = str(result)
    
    # Initialize the sum of digits
    sum_digits = 0
    
    # Iterate over each digit and add it to the sum
    for digit in result_str:
        sum_digits += int(digit)
    
    # Return the sum of digits
    return sum_digits