def differ_At_One_Bit_Pos(n, m):
    # XOR the two numbers
    xor = n ^ m
    # Count the number of set bits (1s) in the XOR result
    count = 0
    while xor > 0:
        count += xor & 1
        xor >>= 1
    # If there is exactly one set bit, return True, else return False
    return count == 1