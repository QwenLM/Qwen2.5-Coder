def lateralsurface_cube(side_length):
    return 4 * side_length ** 2