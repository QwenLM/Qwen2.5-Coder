def remove_elements(list1, list2):
    return [element for element in list1 if element not in list2]