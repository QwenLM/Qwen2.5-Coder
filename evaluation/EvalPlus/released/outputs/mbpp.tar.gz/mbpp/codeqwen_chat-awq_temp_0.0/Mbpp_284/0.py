def check_element(lst, element):
    return all(item == element for item in lst)