def add_dict_to_tuple(tup, dict_):
    return tup + (dict_,)