def check_occurrences(tuples_list):
    occurrences_dict = {}
    for tup in tuples_list:
        if tup in occurrences_dict:
            occurrences_dict[tup] += 1
        else:
            occurrences_dict[tup] = 1
    return occurrences_dict