def check_none(tup):
    return None in tup