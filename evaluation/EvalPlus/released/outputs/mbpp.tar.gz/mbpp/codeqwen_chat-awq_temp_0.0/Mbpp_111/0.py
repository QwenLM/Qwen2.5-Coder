def common_in_nested_lists(nested_lists):
    # Flatten the nested lists
    flat_list = [item for sublist in nested_lists for item in sublist]
    # Find the common elements
    common_elements = set(flat_list) & set(flat_list)
    return list(common_elements)