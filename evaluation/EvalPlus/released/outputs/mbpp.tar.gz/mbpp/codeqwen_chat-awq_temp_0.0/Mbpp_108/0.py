def merge_sorted_list(list1, list2, list3):
    # Combine all lists
    combined_list = list1 + list2 + list3
    # Sort the combined list
    combined_list.sort()
    # Return the sorted list
    return combined_list