def volume_cube(side_length):
    return side_length ** 3