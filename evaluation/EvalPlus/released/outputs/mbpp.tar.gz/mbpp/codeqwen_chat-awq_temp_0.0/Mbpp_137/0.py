import math

def zero_count(arr):
    zero_num = arr.count(0)
    non_zero_num = len(arr) - zero_num
    return zero_num / non_zero_num