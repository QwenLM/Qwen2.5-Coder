def replace_spaces(s):
    return s.replace(' ', '_').replace('_', ' ')