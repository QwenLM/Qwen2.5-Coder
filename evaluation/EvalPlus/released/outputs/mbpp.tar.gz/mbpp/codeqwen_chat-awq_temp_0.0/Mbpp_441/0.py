def surfacearea_cube(side):
    return 6 * side * side