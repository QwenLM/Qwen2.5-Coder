def check_min_heap(arr, i=0, n=None):
    if n is None:
        n = len(arr)
    if i &amp;amp;amp;amp;gt; (n - 2) // 2:
        return True
    if arr[i] &amp;amp;amp;amp;lt;= arr[2 * i + 1] and arr[i] &amp;amp;amp;amp;lt;= arr[2 * i + 2] and check_min_heap(arr, 2 * i + 1, n) and check_min_heap(arr, 2 * i + 2, n):
        return True
    return False