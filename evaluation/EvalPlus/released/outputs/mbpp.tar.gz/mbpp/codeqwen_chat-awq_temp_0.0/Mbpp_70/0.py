def get_equal(tuples):
    # Get the length of the first tuple
    first_tuple_length = len(tuples[0])
    
    # Iterate over the tuples
    for t in tuples:
        # If the current tuple's length is not equal to the first tuple's length, return False
        if len(t) != first_tuple_length:
            return False
    
    # If all tuples have the same length, return True
    return True