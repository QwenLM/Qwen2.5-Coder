def check_greater(arr, num):
    return num > max(arr)