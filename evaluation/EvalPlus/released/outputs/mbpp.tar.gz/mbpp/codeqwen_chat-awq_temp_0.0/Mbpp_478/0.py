def remove_lowercase(s):
    return ''.join(c for c in s if c.isupper())