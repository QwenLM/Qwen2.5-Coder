def Find_Min(lst):
    # Find the minimum length of the sublists
    min_len = min(len(sublist) for sublist in lst)
    # Return the sublist(s) with the minimum length
    return [sublist for sublist in lst if len(sublist) == min_len]