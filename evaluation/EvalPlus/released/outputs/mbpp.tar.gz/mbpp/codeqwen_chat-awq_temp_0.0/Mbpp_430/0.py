def parabola_directrix(a, b, c):
    # The formula for the directrix of a parabola is y = c - (b^2 - 1) * 4 * a
    directrix = c - (b**2 - 1) * 4 * a
    return directrix