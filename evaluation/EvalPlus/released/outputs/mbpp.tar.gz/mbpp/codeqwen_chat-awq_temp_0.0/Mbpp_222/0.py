def check_type(tup):
    first_element_type = type(tup[0])
    for element in tup:
        if type(element) != first_element_type:
            return False
    return True