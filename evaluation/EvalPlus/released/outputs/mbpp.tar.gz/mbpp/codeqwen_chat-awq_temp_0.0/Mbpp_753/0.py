def min_k(records, k):
    # Sort the records based on the second element of each tuple
    records.sort(key=lambda x: x[1])
    # Return the first k records
    return records[:k]