def extract_quotation(s):
    return [s[i+1:j] for i, j in [(m.start(), m.end()) for m in re.finditer('"([^"]*)"', s)]]