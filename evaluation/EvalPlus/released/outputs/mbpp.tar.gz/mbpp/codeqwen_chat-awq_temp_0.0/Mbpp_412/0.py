def remove_odd(numbers):
    return [num for num in numbers if num % 2 == 0]