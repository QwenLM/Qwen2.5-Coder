def reverse_words(s):
    return ' '.join(s.split()[::-1])