def second_smallest(numbers):
    # Remove duplicates
    unique_numbers = list(set(numbers))
    # Sort the list in ascending order
    unique_numbers.sort()
    # Return the second smallest number
    return unique_numbers[1]