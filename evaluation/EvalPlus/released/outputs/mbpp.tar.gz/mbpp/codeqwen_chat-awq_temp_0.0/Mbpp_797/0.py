def sum_in_range(l, r):
    # Initialize sum
    sum = 0
    # Iterate over the range
    for i in range(l, r+1):
        # Check if the number is odd
        if i % 2 != 0:
            # Add the number to the sum
            sum += i
    # Return the sum
    return sum