def is_Even(n):
    if n % 2 == 0:
        return True
    else:
        return False