def find_dissimilar(tup1, tup2):
    # Use set difference to find dissimilar elements
    dissimilar_elements = tuple(set(tup1) ^ set(tup2))
    return dissimilar_elements