def max_Product(arr):
    # Initialize two variables to store the maximum product
    max_product = float('-inf')
    max_product_pair = (0, 0)

    # Iterate over the array to find the pair with the highest product
    for i in range(len(arr)):
        for j in range(i + 1, len(arr)):
            product = arr[i] * arr[j]
            if product > max_product:
                max_product = product
                max_product_pair = (arr[i], arr[j])

    return max_product_pair