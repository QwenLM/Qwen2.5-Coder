def check_char(s):
    if s[0] == s[-1]:
        return "Valid"
    else:
        return "Invalid"