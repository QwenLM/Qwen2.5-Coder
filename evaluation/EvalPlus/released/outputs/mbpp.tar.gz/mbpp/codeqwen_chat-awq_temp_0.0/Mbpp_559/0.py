def max_sub_array_sum(arr, size):
    max_so_far = arr[0]
    max_ending_here = arr[0]
    for i in range(1, size):
        max_ending_here = max(arr[i], max_ending_here + arr[i])
        max_so_far = max(max_so_far, max_ending_here)
    return max_so_far