def count_first_elements(tup):
    for i in range(len(tup)):
        if isinstance(tup[i], tuple):
            return i
    return len(tup)