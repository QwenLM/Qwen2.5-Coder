def next_power_of_2(n):
    """
    Write a python function to find the smallest power of 2 greater than or equal to n.
    assert next_power_of_2(0) == 1
    """
    if n == 0:
        return 1
    power = 1
    while power < n:
        power *= 2
    return power