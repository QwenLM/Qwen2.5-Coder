def extract_freq(tuples_list):
    # Convert the list of tuples to a set of tuples to remove duplicates
    unique_tuples = set(tuples_list)
    # Return the number of unique tuples
    return len(unique_tuples)