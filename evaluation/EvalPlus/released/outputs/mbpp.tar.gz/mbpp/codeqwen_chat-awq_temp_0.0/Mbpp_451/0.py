def remove_whitespaces(s):
    return s.replace(" ", "")