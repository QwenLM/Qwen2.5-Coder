def count_X(tup, x):
    return tup.count(x)