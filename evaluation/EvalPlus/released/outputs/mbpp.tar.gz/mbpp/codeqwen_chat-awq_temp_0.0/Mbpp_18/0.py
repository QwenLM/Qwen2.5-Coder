def remove_dirty_chars(str1, str2):
    # Create a set of characters in str2 for quick lookup
    dirty_chars = set(str2)
    # Use a list comprehension to filter out characters in str1 that are in dirty_chars
    clean_str1 = ''.join([char for char in str1 if char not in dirty_chars])
    return clean_str1