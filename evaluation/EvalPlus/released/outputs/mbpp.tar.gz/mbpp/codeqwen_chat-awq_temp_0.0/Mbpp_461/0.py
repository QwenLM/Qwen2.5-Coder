def upper_ctr(s):
    count = 0
    for char in s:
        if char.isupper():
            count += 1
    return count