def is_undulating(n):
    n = str(n)
    if len(n) < 3 or n[0] == n[1] == n[2]:
        return False
    for i in range(2, len(n)):
        if i % 2 == 0 and n[i] != n[0]:
            return False
        elif i % 2 != 0 and n[i] != n[2]:
            return False
    return True