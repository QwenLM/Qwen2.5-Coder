def extract_values(s):
    return [i[1:-1] for i in s.split(',')]