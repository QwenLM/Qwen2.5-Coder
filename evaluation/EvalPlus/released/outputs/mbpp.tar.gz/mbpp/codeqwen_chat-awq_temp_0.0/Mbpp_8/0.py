def square_nums(nums):
    return [num ** 2 for num in nums]