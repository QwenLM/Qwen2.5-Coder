def replace_list(lst1, lst2):
    lst1[-1:] = lst2
    return lst1