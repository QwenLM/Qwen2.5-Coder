def count_charac(string):
    return len(string)