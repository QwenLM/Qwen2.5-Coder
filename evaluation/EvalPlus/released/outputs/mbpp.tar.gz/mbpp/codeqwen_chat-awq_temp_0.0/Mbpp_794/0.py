import re

def text_starta_endb(text):
    pattern = '^a.*b$'
    return bool(re.match(pattern, text))