def insert_element(lst, element):
    return [item for el in lst for item in (element, el)]
