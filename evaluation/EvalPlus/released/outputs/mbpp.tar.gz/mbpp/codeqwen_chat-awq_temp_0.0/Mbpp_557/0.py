def toggle_string(s):
    return ''.join([char.lower() if char.isupper() else char.upper() for char in s])