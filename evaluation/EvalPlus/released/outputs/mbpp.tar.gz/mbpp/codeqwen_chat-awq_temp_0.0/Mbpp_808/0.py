def check_K(tup, k):
    return k in tup