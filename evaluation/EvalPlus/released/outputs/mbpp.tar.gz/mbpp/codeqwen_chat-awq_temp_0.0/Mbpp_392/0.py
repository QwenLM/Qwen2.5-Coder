def get_max_sum(n):
    # Initialize a list to store the maximum sums for each number up to n
    max_sums = [0] * (n + 1)
    
    # Base cases
    max_sums[0] = 0
    max_sums[1] = 1
    
    # Fill in the max_sums list using the given equation
    for i in range(2, n + 1):
        max_sums[i] = max(i, max_sums[i // 2] + max_sums[i // 3] + max_sums[i // 4] + max_sums[i // 5])
    
    # Return the maximum sum for n
    return max_sums[n]