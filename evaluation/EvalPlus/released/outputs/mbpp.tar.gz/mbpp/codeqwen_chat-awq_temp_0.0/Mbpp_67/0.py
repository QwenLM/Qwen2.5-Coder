def bell_number(n):
    # Initialize a 2D list with zeros
    dp = [[0 for _ in range(n+1)] for _ in range(n+1)]
    
    # Base case: There is one way to partition a set of 0 Bell numbers
    dp[0][0] = 1
    
    # Fill the DP table
    for i in range(1, n+1):
        dp[i][0] = dp[i-1][i-1]
        for j in range(1, i+1):
            dp[i][j] = dp[i-1][j-1] + dp[i][j-1]
    
    # The answer is the last element in the DP table
    return dp[n][0]