def comb_sort(arr):
    gap = len(arr)
    shrink_factor = 1.3
    is_sorted = False

    while not is_sorted or gap > 1:
        gap = int(gap / shrink_factor)
        if gap < 1:
            gap = 1
        is_sorted = True
        for i in range(len(arr) - gap):
            if arr[i] > arr[i + gap]:
                arr[i], arr[i + gap] = arr[i + gap], arr[i]
                is_sorted = False

    return arr