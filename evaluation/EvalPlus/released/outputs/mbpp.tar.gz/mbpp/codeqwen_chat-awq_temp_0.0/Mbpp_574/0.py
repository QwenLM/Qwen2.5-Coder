import math

def surfacearea_cylinder(radius, height):
    base_area = math.pi * radius ** 2
    lateral_area = 2 * math.pi * radius * height
    surface_area = 2 * base_area + lateral_area
    return round(surface_area, 2)