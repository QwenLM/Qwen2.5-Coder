def amicable_numbers_sum(n):
    def sum_of_divisors(x):
        return sum([i for i in range(1, x) if x % i == 0])

    amicable_sum = 0
    for a in range(2, n + 1):
        b = sum_of_divisors(a)
        if a != b and sum_of_divisors(b) == a:
            amicable_sum += a
    return amicable_sum