def square_perimeter(side_length):
    return 4 * side_length