def string_to_tuple(s):
    return tuple(s)