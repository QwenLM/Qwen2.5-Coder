import cmath

def convert(complex_num):
    return cmath.polar(complex_num)