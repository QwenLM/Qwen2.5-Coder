def max_difference(pairs):
    # Find the minimum and maximum values in the pairs
    min_val = min(pair[0] for pair in pairs)
    max_val = max(pair[1] for pair in pairs)
    
    # Return the difference between the maximum and minimum values
    return max_val - min_val