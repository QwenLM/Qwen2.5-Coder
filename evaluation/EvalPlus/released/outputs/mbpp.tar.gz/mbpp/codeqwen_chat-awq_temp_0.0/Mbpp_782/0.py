def odd_length_sum(arr):
    total_sum = 0
    n = len(arr)
    for i in range(n):
        total_sum += (i + 1) * (n - i) * arr[i]
    return total_sum