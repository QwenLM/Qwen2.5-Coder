def find_sum(lst):
    # Create an empty dictionary to store the frequency of each element
    freq = {}
    for num in lst:
        if num in freq:
            freq[num] += 1
        else:
            freq[num] = 1
    
    # Initialize the sum to 0
    sum = 0
    
    # Iterate over the dictionary and add the elements with frequency 1 to the sum
    for num, count in freq.items():
        if count == 1:
            sum += num
    
    return sum