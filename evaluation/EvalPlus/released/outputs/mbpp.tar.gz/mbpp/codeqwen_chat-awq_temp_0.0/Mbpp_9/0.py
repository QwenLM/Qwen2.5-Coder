def find_Rotations(s):
    # If the string is already a palindrome, no rotation is needed
    if s == s[::-1]:
        return 0
    
    # Find the index of the first character that is not equal to its corresponding character in the reversed string
    for i in range(len(s)):
        if s[i] != s[len(s) - i - 1]:
            # Rotate the string from the index of the first non-matching character to the end
            rotated_s = s[i:] + s[:i]
            # If the rotated string is a palindrome, return the number of rotations
            if rotated_s == rotated_s[::-1]:
                return len(s) - i
    
    # If no rotation results in a palindrome, return -1
    return -1