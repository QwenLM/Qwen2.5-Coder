def tup_string(tup):
    return ''.join(tup)