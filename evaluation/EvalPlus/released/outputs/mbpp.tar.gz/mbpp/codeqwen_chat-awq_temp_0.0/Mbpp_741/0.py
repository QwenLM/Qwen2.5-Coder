def all_Characters_Same(input_string):
    return len(set(input_string)) == 1