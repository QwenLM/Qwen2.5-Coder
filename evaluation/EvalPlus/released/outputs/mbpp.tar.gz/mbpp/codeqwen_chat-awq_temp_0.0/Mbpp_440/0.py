import re

def find_adverb_position(sentence):
    # Regular expression to find words ending with 'ly'
    pattern = r'\b\w+ly\b'
    matches = re.finditer(pattern, sentence)
    
    for match in matches:
        # Return the start and end positions of the first match, along with the adverb itself
        return (match.start(), match.end(), match.group(0))

# Test the function
assert find_adverb_position("clearly!! we can see the sky") == (0, 7, 'clearly')