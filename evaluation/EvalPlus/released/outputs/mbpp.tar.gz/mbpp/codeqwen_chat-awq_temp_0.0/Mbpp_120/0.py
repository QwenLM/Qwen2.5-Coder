def max_product_tuple(lst):
    # Calculate the absolute product of each pair of tuples
    products = [abs(x * y) for x, y in lst]
    # Return the maximum product
    return max(products)