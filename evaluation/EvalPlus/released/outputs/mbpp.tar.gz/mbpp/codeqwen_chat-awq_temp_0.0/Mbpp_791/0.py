def remove_nested(tup):
    result = tuple(item for item in tup if not isinstance(item, tuple))
    return result