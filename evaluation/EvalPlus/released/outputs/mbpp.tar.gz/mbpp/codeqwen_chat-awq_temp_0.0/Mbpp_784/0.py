def mul_even_odd(lst):
    even_num = [num for num in lst if num % 2 == 0]
    odd_num = [num for num in lst if num % 2 != 0]
    return even_num[0] * odd_num[0] if even_num and odd_num else 0