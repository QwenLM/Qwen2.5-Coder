def find_Odd_Pair(arr, n):
    odd_count = 0
    even_count = 0
    for i in range(n):
        if arr[i] % 2 == 0:
            even_count += 1
        else:
            odd_count += 1
    return odd_count * even_count