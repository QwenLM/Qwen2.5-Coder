def unique_Element(lst):
    return len(set(lst)) == 1