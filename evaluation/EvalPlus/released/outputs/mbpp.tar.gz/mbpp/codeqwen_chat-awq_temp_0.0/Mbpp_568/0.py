def empty_list(N):
    return [{} for _ in range(N)]