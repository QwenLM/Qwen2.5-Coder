import sys

def tuple_size(t):
    return sys.getsizeof(t)