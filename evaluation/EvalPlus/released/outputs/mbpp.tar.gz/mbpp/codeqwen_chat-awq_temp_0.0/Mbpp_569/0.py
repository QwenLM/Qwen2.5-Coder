def sort_sublists(lst):
    return [sorted(sublist) for sublist in lst]