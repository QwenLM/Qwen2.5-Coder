def string_to_list(s):
    return s.split(" ")