def average_tuple(tuples):
    return [sum(tup)/len(tup) for tup in tuples]