def sort_numeric_strings(lst):
    return sorted(lst, key=lambda x: int(x))