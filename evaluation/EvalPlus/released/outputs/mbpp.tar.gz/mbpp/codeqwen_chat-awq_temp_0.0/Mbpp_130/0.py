def max_occurrences(lst):
    # Create a dictionary to store the frequency of each item
    freq_dict = {}
    for item in lst:
        if item in freq_dict:
            freq_dict[item] += 1
        else:
            freq_dict[item] = 1
    # Find the item with the maximum frequency
    max_item = max(freq_dict, key=freq_dict.get)
    return max_item