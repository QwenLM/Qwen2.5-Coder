def number_of_substrings(s):
    return len(s) * (len(s) + 1) // 2