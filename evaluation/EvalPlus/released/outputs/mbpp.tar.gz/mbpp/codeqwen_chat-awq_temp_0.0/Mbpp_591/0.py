def swap_List(lst):
    # Check if the list is empty or contains only one element
    if len(lst) <= 1:
        return lst
    
    # Swap the first and last elements
    lst[0], lst[-1] = lst[-1], lst[0]
    
    return lst