def is_Diff(n):
    return n % 11 == 0