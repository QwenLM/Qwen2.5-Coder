def test_duplicate(arr):
    # Create an empty set to store unique elements
    unique_elements = set()
    
    # Iterate over each element in the array
    for element in arr:
        # If the element is already in the set, it's a duplicate
        if element in unique_elements:
            return True
        # Otherwise, add the element to the set
        unique_elements.add(element)
    
    # If we haven't found any duplicates, return False
    return False