def find_kth(arr1, arr2, k):
    i, j = 0, 0
    while i < len(arr1) and j < len(arr2):
        if arr1[i] < arr2[j]:
            i += 1
        else:
            j += 1
        if i + j == k:
            return arr1[i - 1] if i > 0 else arr2[j - 1]
    return arr1[i - 1] if i > 0 else arr2[j - 1]