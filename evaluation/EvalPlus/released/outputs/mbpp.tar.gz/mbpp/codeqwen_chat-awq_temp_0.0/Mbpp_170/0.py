def sum_range_list(numbers, start_index, end_index):
    return sum(numbers[start_index:end_index+1])