def min_val(lst):
    min_val = lst[0]
    for i in lst:
        if isinstance(i, (int, float)) and i < min_val:
            min_val = i
    return min_val