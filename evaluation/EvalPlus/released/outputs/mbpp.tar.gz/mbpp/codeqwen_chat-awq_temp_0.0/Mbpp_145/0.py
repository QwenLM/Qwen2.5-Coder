def max_Abs_Diff(arr):
    # Initialize minimum and maximum elements as the first element of the array
    min_element = max_element = arr[0]
    
    # Iterate over the array starting from the second element
    for i in range(1, len(arr)):
        # Update minimum and maximum elements if necessary
        min_element = min(min_element, arr[i])
        max_element = max(max_element, arr[i])
    
    # Return the difference between the maximum and minimum elements
    return max_element - min_element