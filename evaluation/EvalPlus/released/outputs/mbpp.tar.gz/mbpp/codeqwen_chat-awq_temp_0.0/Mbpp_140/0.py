def extract_singly(list_of_lists):
    return set(num for sublist in list_of_lists for num in sublist)