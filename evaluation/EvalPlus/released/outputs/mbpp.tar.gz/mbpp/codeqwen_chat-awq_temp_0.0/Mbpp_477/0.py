def is_lower(s):
    return s.lower()