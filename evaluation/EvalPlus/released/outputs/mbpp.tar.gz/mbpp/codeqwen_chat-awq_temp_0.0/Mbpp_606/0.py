import math

def radian_degree(degrees):
    radians = degrees * (math.pi / 180)
    return radians