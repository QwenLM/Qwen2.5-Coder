import math

def triangle_area(radius):
    if radius < 0:
        return None
    else:
        return (3 * math.sqrt(3) * radius * radius) / 4