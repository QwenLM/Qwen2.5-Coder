def median_numbers(a, b, c):
    numbers = [a, b, c]
    numbers.sort()
    return numbers[1]