import math

def lateralsurface_cylinder(radius, height):
    return 2 * math.pi * radius * height