import re

def text_match_wordz_middle(text):
    pattern = r'\b[^z]*z[^z]*\b'
    return bool(re.search(pattern, text))