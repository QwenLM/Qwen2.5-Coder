def min_product_tuple(lst):
    # Calculate the product of each tuple pair
    products = [a*b for a, b in lst]
    # Return the minimum product
    return min(products)