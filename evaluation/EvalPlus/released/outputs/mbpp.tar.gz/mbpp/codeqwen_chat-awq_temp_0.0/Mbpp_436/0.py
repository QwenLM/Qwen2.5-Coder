def neg_nos(nums):
    return [num for num in nums if num < 0]