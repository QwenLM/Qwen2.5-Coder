def get_ludic(n):
    ludics = [1]
    i = 2
    while i <= n:
        if i in ludics:
            ludics.extend([i + j for j in range(i, n + 1, i)])
        i += 1
    return [i for i in range(1, n + 1) if i in ludics]