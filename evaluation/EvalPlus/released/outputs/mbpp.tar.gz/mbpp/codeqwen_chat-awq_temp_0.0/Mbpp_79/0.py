def word_len(word):
    return len(word) % 2 != 0