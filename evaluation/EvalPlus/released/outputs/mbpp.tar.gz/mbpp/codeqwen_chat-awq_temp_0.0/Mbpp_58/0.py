def opposite_Signs(a, b):
    return (a < 0) != (b < 0)