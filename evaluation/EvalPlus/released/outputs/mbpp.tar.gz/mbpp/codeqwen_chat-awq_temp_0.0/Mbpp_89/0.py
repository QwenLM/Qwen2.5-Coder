def closest_num(n):
    return n - 1