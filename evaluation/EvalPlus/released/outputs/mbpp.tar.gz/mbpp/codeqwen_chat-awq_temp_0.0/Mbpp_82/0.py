import math

def volume_sphere(radius):
    return (4/3) * math.pi * (radius ** 3)