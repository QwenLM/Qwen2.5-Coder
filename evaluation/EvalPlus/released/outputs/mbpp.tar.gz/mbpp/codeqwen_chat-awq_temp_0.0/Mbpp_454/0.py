import re

def text_match_wordz(text):
    pattern = '\w*z.\w*'
    if re.search(pattern, text):
        return True
    else:
        return False