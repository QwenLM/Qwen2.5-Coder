def tetrahedral_number(n):
    return n * (n + 1) * (n + 2) // 6