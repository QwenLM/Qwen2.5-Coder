def noprofit_noloss(cost_price, selling_price):
    if cost_price == selling_price:
        return True
    else:
        return False