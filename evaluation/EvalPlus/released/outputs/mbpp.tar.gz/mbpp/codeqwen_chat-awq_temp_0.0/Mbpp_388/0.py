def highest_Power_of_2(n):
    """
    This function finds the highest power of 2 that is less than or equal to n.
    """
    # Initialize the highest power of 2 to 1
    highest_power = 1
    
    # Loop until the highest power of 2 is less than or equal to n
    while highest_power * 2 <= n:
        highest_power *= 2
    
    # Return the highest power of 2
    return highest_power