def multiply_int(a, b):
    return a * b