def tuple_to_dict(tup):
    return dict(zip(tup[::2], tup[1::2]))