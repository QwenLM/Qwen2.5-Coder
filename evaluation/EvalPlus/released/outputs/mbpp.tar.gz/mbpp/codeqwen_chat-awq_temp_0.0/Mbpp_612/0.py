def merge(lst):
    return [i[0] for i in lst], [i[1] for i in lst]