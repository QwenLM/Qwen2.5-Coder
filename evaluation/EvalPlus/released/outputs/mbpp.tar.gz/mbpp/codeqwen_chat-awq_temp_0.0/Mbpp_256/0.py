def count_Primes_nums(n):
    if n <= 2:
        return 0
    count = 0
    for num in range(2, n):
        for i in range(2, num):
            if (num % i) == 0:
                break
        else:
            count += 1
    return count