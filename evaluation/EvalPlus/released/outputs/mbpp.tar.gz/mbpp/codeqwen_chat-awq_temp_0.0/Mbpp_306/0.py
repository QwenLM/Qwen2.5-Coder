def max_sum_increasing_subseq(arr, n, i, k):
    # Initialize the dp array
    dp = [[0 for _ in range(n)] for _ in range(n)]
    
    # Base case: The first element is always part of the increasing subsequence
    for j in range(n):
        dp[0][j] = arr[0] if arr[j] > arr[0] else arr[0]
    
    # Fill the dp array
    for i in range(1, n):
        for j in range(1, n):
            if arr[j] > arr[i] and j > i:
                dp[i][j] = max(dp[i-1][i] + arr[j], dp[i-1][j])
            else:
                dp[i][j] = dp[i-1][j]
    
    # Return the maximum sum including the kth element
    return dp[i][k]

# Test the function
assert max_sum_increasing_subseq([1, 101, 2, 3, 100, 4, 5 ], 7, 4, 6) == 11