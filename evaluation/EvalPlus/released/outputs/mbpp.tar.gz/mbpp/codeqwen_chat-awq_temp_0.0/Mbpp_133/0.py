def sum_negativenum(numbers):
    return sum(num for num in numbers if num < 0)