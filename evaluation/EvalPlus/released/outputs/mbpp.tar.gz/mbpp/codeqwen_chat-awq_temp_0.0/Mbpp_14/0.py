def find_Volume(base, height, length):
    return (base * height * length) / 2