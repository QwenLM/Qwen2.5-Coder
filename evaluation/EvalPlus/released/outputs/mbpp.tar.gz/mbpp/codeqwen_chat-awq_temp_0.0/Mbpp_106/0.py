def add_lists(lst, tup):
    return tup + tuple(lst)