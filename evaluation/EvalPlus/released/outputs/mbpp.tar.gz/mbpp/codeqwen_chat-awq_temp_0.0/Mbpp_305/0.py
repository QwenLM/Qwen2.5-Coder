def start_withp(word_list):
    p_words = [word for word in word_list if word.startswith('p')]
    return tuple(p_words[:2])