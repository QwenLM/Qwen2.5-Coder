def is_polite(n):
    """
    This function checks if a number is polite or not.
    A polite number is a number that can be expressed as the sum of two or more consecutive positive integers.
    """
    count = 0
    i = 1
    while count < n:
        if i % 2 != 0:
            count += 1
        i += 1
    return i - 1

def nth_polite_number(n):
    """
    This function returns the nth polite number.
    """
    return is_polite(n)