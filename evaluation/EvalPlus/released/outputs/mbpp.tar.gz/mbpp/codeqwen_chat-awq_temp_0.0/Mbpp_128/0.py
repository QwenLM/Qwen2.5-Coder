def long_words(n, str):
    # Splitting the string into a list of words
    words = str.split(" ")
    # Using list comprehension to filter out words longer than n characters
    long_words = [word for word in words if len(word) > n]
    return long_words