def split(string):
    return [char for char in string]