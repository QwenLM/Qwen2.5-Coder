def replace_specialchar(text):
    return text.replace(' ', ':').replace(',', ':').replace('.', ':')