def Diff(list1, list2):
    return [i for i in list1 if i not in list2]