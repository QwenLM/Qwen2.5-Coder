def is_upper(string):
    return string.upper()