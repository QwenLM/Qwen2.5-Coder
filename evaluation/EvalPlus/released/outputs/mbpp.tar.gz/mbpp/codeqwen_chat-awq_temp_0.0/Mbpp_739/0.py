def find_Index(n):
    # Initialize the index and the number
    index = 1
    num = 1
    
    # Loop until we find the number with n digits
    while len(str(num)) < n:
        # Increment the number and update the index
        num += index
        index += 1
    
    # Return the index
    return index - 1