def change_date_format(date):
    return date[8:10] + '-' + date[5:7] + '-' + date[0:4]