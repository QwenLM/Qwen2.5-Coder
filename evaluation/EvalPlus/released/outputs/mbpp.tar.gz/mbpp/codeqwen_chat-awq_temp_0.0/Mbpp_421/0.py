def concatenate_tuple(tup):
    return '-'.join(str(i) for i in tup)