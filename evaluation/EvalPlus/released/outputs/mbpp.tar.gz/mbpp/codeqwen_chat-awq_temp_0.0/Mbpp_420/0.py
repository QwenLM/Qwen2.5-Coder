def cube_Sum(n):
    sum = 0
    for i in range(1, n+1):
        sum += (2*i)**3
    return sum