def is_Sum_Of_Powers_Of_Two(n):
    # If the number is less than or equal to 0, it cannot be represented as sum of non-zero powers of 2
    if n <= 0:
        return False
    # If the number is 1, it can be represented as sum of non-zero powers of 2
    elif n == 1:
        return True
    # If the number is greater than 1, check if it can be represented as sum of non-zero powers of 2
    else:
        # If the number is even, it can be represented as sum of non-zero powers of 2
        if n % 2 == 0:
            return is_Sum_Of_Powers_Of_Two(n // 2)
        # If the number is odd, it cannot be represented as sum of non-zero powers of 2
        else:
            return False