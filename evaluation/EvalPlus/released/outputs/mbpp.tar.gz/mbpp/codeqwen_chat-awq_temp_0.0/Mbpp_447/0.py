def cube_nums(nums):
    return [num ** 3 for num in nums]