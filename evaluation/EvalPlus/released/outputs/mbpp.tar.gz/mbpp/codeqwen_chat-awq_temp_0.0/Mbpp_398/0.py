def sum_of_digits(numbers):
    total = 0
    for number in numbers:
        while number > 0:
            total += number % 10
            number = number // 10
    return total