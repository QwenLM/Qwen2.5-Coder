import math

def angle_complex(real, imag):
    return math.atan2(imag, real)