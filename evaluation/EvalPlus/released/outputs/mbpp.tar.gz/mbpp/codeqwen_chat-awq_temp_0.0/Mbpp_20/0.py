def is_woodall(n):
    if n < 1:
        return False
    p = 2
    while p * p <= n:
        if n % p == 0:
            count = 0
            while n % p == 0:
                n //= p
                count += 1
            if count % 2 != 0:
                return False
        p += 1
    if n > 1:
        return False
    return True