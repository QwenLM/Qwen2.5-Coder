def list_to_float(lst):
    return [(float(x), float(y)) for x, y in lst]