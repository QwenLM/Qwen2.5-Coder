def perfect_squares(start, end):
    return [i**2 for i in range(start, end+1) if i**0.5 == int(i**0.5)]