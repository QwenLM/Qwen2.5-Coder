def check_monthnumber_number(month_number):
    # List of months with 30 days
    months_with_30_days = [4, 6, 9, 11]
    
    # Check if the given month number is in the list
    if month_number in months_with_30_days:
        return True
    else:
        return False