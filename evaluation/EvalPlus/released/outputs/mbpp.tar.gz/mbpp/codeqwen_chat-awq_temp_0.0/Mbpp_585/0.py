def expensive_items(dataset, n):
    # Sort the dataset by price in descending order
    dataset.sort(key=lambda x: x['price'], reverse=True)
    
    # Return the first n items from the sorted dataset
    return dataset[:n]