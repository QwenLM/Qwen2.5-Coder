def sub_list(list1, list2):
    return [a - b for a, b in zip(list1, list2)]