import math

def surfacearea_sphere(radius):
    return 4 * math.pi * radius ** 2