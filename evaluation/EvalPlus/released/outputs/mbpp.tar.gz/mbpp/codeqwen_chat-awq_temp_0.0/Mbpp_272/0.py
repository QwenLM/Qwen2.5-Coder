def rear_extract(tuples_list):
    return [t[-1] for t in tuples_list]