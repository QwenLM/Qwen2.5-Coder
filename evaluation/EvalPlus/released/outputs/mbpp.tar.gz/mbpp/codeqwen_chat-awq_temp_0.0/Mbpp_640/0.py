import re

def remove_parenthesis(lst):
    result = []
    for item in lst:
        result.append(re.sub(r'\([^)]*\)', '', item))
    return result