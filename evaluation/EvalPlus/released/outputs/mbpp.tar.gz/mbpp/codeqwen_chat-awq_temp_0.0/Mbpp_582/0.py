def my_dict(dictionary):
    return not bool(dictionary)