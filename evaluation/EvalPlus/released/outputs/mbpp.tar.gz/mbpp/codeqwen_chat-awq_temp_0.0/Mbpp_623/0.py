def nth_nums(nums, n):
    return [num ** n for num in nums]