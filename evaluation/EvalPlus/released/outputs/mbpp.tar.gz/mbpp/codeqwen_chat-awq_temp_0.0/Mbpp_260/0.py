def newman_prime(n):
    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num**0.5) + 1):
            if num % i == 0:
                return False
        return True

    def nsw_prime(n):
        if n == 1:
            return 2
        elif n == 2:
            return 3
        else:
            a, b = 2, 3
            while True:
                a, b = b, 2 * b + a
                if is_prime(b):
                    n -= 1
                    if n == 0:
                        return b

    return nsw_prime(n)