def removezero_ip(ip):
    return ".".join(str(int(i)) for i in ip.split("."))