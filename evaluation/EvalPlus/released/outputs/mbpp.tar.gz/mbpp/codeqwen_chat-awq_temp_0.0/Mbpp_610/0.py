def remove_kth_element(lst, k):
    return lst[:k] + lst[k+1:]