def tuple_str_int(tup_str):
    # Remove the parentheses and split the string by comma
    str_list = tup_str[1:-1].split(', ')
    # Convert each string in the list to an integer and create a tuple
    int_tup = tuple(int(i) for i in str_list)
    return int_tup