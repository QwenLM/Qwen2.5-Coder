import math

def next_Perfect_Square(n):
    root = math.ceil(math.sqrt(n))
    return root * root