def next_smallest_palindrome(n):
    # Convert the integer to a string
    str_n = str(n)
    # Start from the next number
    for i in range(n+1, 10**6):
        # Check if the number is a palindrome
        if str(i) == str(i)[::-1]:
            return i