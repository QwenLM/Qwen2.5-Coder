def sum_series(n):
    if n < 0:
        return 0
    elif n == 0:
        return 0
    elif n == 1:
        return 0
    else:
        return n - 2 * (n // 2)