def is_decimal(s):
    try:
        float_val = float(s)
        if float_val.is_integer():
            return False
        else:
            return round(float_val, 2) == float_val
    except ValueError:
        return False