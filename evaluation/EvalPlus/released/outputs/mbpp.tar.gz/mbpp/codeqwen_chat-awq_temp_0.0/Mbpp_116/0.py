def tuple_to_int(tup):
    return int("".join(map(str, tup)))