def empty_dict(dict_list):
    return all(len(d) == 0 for d in dict_list)