def find_tuples(tuples_list, k):
    result = []
    for tup in tuples_list:
        if all(num % k == 0 for num in tup):
            result.append(tup)
    return result