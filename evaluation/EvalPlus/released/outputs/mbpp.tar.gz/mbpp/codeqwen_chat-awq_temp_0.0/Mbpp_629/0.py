def Split(numbers):
    even_numbers = [num for num in numbers if num % 2 == 0]
    return even_numbers