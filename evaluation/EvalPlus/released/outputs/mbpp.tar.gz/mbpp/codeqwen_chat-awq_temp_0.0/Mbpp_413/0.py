def extract_nth_element(tuples_list, n):
    return [t[n] for t in tuples_list]