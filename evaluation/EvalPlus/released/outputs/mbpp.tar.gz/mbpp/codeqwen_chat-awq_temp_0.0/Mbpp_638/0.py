def wind_chill(v, t):
    """
    Calculate the wind chill index rounded to the next integer given the wind velocity in km/h and a temperature in celsius.
    """
    if t < 10 or v < 4.8:
        return None
    wci = 13.12 + 0.6215 * t - 11.37 * v ** 0.16 + 0.3965 * t * v ** 0.16
    return round(wci)