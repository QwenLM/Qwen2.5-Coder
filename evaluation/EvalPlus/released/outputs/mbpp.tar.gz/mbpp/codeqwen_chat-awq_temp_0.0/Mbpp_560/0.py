def union_elements(tup1, tup2):
    # Combine the two tuples
    combined = tup1 + tup2
    # Convert the combined tuple to a set to remove duplicates
    unique = set(combined)
    # Convert the set back to a tuple and sort it
    sorted_unique = tuple(sorted(unique))
    return sorted_unique