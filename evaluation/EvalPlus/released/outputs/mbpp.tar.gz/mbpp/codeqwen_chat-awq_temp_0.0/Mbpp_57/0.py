def find_Max_Num(digits):
    # Convert each digit to a string and sort the list in descending order
    digits.sort(key=str, reverse=True)
    
    # Join the sorted digits to form the largest number
    max_num = int(''.join(map(str, digits)))
    
    return max_num