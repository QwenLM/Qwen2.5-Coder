def extract_rear(tup):
    return [s[-1] for s in tup]