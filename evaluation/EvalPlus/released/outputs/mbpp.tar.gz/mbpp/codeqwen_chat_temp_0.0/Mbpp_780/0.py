from itertools import combinations

def find_combinations(tuples):
    result = []
    for r in range(1, len(tuples) + 1):
        for combo in combinations(tuples, r):
            result.append(tuple(sum(pair) for pair in zip(*combo)))
    return result