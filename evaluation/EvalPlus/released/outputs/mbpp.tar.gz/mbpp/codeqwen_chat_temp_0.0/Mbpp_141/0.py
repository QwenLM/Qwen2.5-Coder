def pancake_sort(arr):
    n = len(arr)
    for i in range(n, 1, -1):
        # Find index of the maximum element in arr[0..i-1]
        max_idx = arr.index(max(arr[:i]))
        
        # Move the maximum element to end of current array if it's not already at the end
        if max_idx != i-1:
            # First move maximum number to beginning
            arr[:max_idx+1] = arr[:max_idx+1][::-1]
            # Now move the maximum number to end by reversing current array
            arr[:i] = arr[:i][::-1]
    return arr