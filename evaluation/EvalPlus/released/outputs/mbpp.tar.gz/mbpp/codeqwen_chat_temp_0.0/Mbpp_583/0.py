def catalan_number(n):
    # Initialize a list to store catalan numbers
    catalan = [0] * (n+1)
    
    # Base cases
    catalan[0] = 1
    if n > 0:
        catalan[1] = 1
    
    # Fill catalan numbers in bottom-up manner
    for i in range(2, n+1):
        for j in range(i):
            catalan[i] += catalan[j] * catalan[i-j-1]
    
    return catalan[n]