def bell_Number(n):
    # Initialize a list to store the Bell numbers
    bell = [[0 for _ in range(n+1)] for _ in range(n+1)]
    
    # Base case
    bell[0][0] = 1
    
    # Fill the Bell numbers table
    for i in range(1, n+1):
        bell[i][0] = bell[i-1][i-1]
        for j in range(1, i+1):
            bell[i][j] = bell[i-1][j-1] + bell[i][j-1]
    
    # Return the nth Bell number
    return bell[n][0]