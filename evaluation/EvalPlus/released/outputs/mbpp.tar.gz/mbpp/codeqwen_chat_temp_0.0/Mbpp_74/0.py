def is_samepatterns(colors, patterns):
    if len(colors) != len(patterns):
        return False
    pattern_to_color = {}
    color_to_pattern = {}
    for color, pattern in zip(colors, patterns):
        if pattern in pattern_to_color and pattern_to_color[pattern] != color:
            return False
        if color in color_to_pattern and color_to_pattern[color] != pattern:
            return False
        pattern_to_color[pattern] = color
        color_to_pattern[color] = pattern
    return True