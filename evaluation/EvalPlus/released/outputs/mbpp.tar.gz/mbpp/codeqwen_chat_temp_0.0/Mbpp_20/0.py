def is_woodall(n):
    if n < 1:
        return False
    i = 1
    while n % (i + 1) == 0:
        n /= i + 1
        i += 1
    return n == i