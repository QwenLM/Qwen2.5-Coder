def Find_Min(lst):
    # Initialize the minimum length to the length of the first sublist
    min_len = len(lst[0])
    # Initialize the minimum sublist to the first sublist
    min_sublist = lst[0]
    # Iterate over the sublists in the list
    for sublist in lst:
        # If the current sublist is shorter than the minimum sublist found so far
        if len(sublist) < min_len:
            # Update the minimum length and the minimum sublist
            min_len = len(sublist)
            min_sublist = sublist
    # Return the minimum sublist
    return min_sublist