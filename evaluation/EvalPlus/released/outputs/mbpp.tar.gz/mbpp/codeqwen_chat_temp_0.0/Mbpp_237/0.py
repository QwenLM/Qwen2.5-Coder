def check_occurences(tuples_list):
    # Create an empty dictionary
    dict_map = {}
    # Iterate over each tuple in the list
    for tup in tuples_list:
        # If the tuple is already in the dictionary, increment its count
        if tup in dict_map:
            dict_map[tup] += 1
        # If the tuple is not in the dictionary, add it with a count of 1
        else:
            dict_map[tup] = 1
    # Return the dictionary
    return dict_map