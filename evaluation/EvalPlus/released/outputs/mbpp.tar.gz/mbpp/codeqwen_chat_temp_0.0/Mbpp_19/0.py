def test_duplicate(arr):
    # Create an empty set to store unique elements
    unique_elements = set()
    
    # Iterate over the array
    for num in arr:
        # If the number is already in the set, it's a duplicate
        if num in unique_elements:
            return True
        # Otherwise, add the number to the set
        unique_elements.add(num)
    
    # If we get here, there are no duplicates
    return False