def occurance_substring(string, substring):
    try:
        start = string.index(substring)
        return (substring, start, start + len(substring))
    except ValueError:
        return None