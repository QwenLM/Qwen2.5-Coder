def sum_range_list(numbers, start, end):
    return sum(numbers[start:end+1])