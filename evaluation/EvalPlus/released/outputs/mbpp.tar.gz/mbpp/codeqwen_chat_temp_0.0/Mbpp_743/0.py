def rotate_right(lst, n):
    return lst[-n:] + lst[:-n]