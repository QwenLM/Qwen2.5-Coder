def sum_length_names(names):
    # Initialize the sum to 0
    total_length = 0
    # Iterate over the names
    for name in names:
        # Check if the name starts with a lowercase letter
        if not name[0].islower():
            # Add the length of the name to the total length
            total_length += len(name)
    # Return the total length
    return total_length

# Test the function
assert sum_length_names(['sally', 'Dylan', 'rebecca', 'Diana', 'Joanne', 'keith']) == 16