def extract_string(lst, size):
    return [s for s in lst if len(s) == size]

# Test the function