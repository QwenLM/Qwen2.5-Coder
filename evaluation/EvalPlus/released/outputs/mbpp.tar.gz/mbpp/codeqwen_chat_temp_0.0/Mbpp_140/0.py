def extract_singly(list_of_lists):
    # Flatten the list of lists into a single list
    flattened_list = [item for sublist in list_of_lists for item in sublist]
    # Convert the list to a set to remove duplicates
    result_set = set(flattened_list)
    return result_set