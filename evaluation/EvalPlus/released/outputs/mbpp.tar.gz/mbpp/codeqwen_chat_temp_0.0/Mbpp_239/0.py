def get_total_number_of_sequences(m, n):
    # Initialize a 2D array to store the number of sequences
    dp = [[0 for _ in range(n+1)] for _ in range(m+1)]
    
    # Base case: There is 1 sequence of length 1 for each number from 1 to m
    for i in range(1, m+1):
        dp[i][1] = 1
    
    # Fill the dp array
    for i in range(2, m+1):
        for j in range(2, n+1):
            for k in range(i//2+1, i+1):
                dp[i][j] += dp[k][j-1]
    
    # The answer is the sum of sequences of length n for all numbers from 1 to m
    return sum(dp[i][n] for i in range(1, m+1))