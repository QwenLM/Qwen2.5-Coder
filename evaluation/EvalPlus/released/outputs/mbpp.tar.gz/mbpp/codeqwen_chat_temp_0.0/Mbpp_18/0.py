def remove_dirty_chars(s1, s2):
    # Create a set of characters in s2 for quick lookup
    dirty_chars = set(s2)
    # Use a list comprehension to filter out characters in s1 that are in s2
    cleaned_s1 = ''.join([char for char in s1 if char not in dirty_chars])
    return cleaned_s1