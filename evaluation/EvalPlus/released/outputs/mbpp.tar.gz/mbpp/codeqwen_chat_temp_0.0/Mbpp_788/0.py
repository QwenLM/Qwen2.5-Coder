def new_tuple(lst, str):
    return tuple(lst + [str])