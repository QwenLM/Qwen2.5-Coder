def remove_Occ(s, c):
    first_index = s.find(c)
    last_index = s.rfind(c)
    if first_index != -1 and last_index != -1:
        return s[:first_index] + s[first_index + 1:last_index] + s[last_index + 1:]
    return s