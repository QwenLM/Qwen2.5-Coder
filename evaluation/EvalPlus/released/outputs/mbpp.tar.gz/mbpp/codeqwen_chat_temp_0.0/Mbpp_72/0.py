def dif_Square(n):
    # Iterate through all numbers from 0 to n
    for i in range(n + 1):
        # Check if the difference of squares of i and (n - i) is equal to n
        if ((i * i) - ((n - i) * (n - i))) == n:
            return True
    # If no such pair is found, return False
    return False